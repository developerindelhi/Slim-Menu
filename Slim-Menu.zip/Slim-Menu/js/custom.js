jQuery(document).ready(function(){
	jQuery('.slimmenu').slimmenu({
		resizeWidth: '800',
		collapserTitle: 'Main Menu',
		animSpeed:'medium',
		indentChildren: true,
		childrenIndenter: '&raquo;'
	});
});